let score = 0;
let cube = document.querySelector("#cube");
let scoreText = document.querySelector("#scoreText");

function moveCube() {
  let x = (Math.random() * 4) - 2;   // random between -2 and 2
  let y = (Math.random() * 2) + 1;   // random between 1 and 3
  let z = -3;                        // keep it in front of player

  cube.setAttribute("position", `${x} ${y} ${z}`);
}
cube.addEventListener("click", () => {
  moveCube()
  score++
   scoreText.setAttribute("text", `value: Score: ${score}`);
  moveCube();
});